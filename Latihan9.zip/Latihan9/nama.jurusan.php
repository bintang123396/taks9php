<?php 
require_once 'class_jurusan.php';

$dm = new fruit();
$ppl = new fruit();
$dkv = new fruit();
$ak = new fruit();

$dm->set_name(': Digital Marketing');
$ppl->set_name(': Pengembangan Perangkat Lunak');
$dkv->set_name(': Desain Komunikasi Visual');
$ak->set_name(': Akutansi');

echo 'Nama Jurusan '.$dm->get_name();
echo '<br/>Nama Jurusan '.$ppl->get_name();
echo '<br/>Nama Jurusan '.$dkv->get_name();
echo '<br/>Nama Jurusan '.$ak->get_name();
 ?>