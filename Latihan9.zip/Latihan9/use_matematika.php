<?php 
require_once 'class_matematika.php';

Matematika::$counter++;
Matematika::$counter++;
Matematika::naikanCounter();
echo 'counter sekarang : '.Matematika::$counter;
echo '<hr/>';

$x =Matematika::tambahkan(4,8);
echo "4 + 8 = $x";
echo '<hr/>';

echo 'Nilai PHI : '.Matematika::PHI;
$luas_lingkaran = matematika::luaslingkaran(8);
echo '<br/> Lingkaran dengan Jari-jari 8 adalah : '. $luas_lingkaran;
echo '<hr/>'; 

$x =Matematika::kurangkan(35,15);
echo "35 - 15 = $x";
echo '<hr/>';
 ?>